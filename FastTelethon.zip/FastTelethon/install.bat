@echo off
title Myrient - Instalacao
echo.
echo       Myrient - Instalando ambiente    
echo.

pip cache purge
echo.

echo  Criando ambiente virtual...
python -m venv venv
if errorlevel 1 (
    echo  [ERRO] Falha ao criar venv. Verifique se o Python esta instalado.
    pause
    exit /b 1
)

echo  Ativando ambiente virtual...
call venv\Scripts\activate.bat

echo  Limpando cache novamente...
pip cache purge

echo  Instalando dependencias...
pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo  [ERRO] Falha na instalacao. Verifique sua conexao e tente novamente.
    pause
    exit /b 1
)

echo.
echo       Instalacao concluida com         
echo       sucesso! Execute run.bat         
echo.
timeout /t 3
