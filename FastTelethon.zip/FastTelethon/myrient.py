#!/usr/bin/env python3

import asyncio
import json
import logging
import platform
import re
import subprocess
import sys
import time
import zipfile
from pathlib import Path

import httpx
from bs4 import BeautifulSoup
from FastTelethon import upload_file as _ft_upload_file
from telethon import TelegramClient
from telethon.tl.types import DocumentAttributeFilename, MessageMediaDocument

BASE_URL     = "https://myrient.erista.me/files/"
CONFIG_FILE  = Path("config.json")
DOWNLOAD_DIR = Path("./downloads")
FAILED_LOG   = Path("./failed_downloads.txt")
ARIA2C_DIR   = Path(__file__).parent / "bin"
ARIA2C_WIN   = ARIA2C_DIR / "aria2c.exe"

MB            = 1024 * 1024
SPLIT_NORMAL  = 1800 * MB
SPLIT_PREMIUM = 3800 * MB
READ_CHUNK    = 64 * MB

RESET  = "\033[0m"
BOLD   = "\033[1m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
CYAN   = "\033[96m"
RED    = "\033[91m"
DIM    = "\033[2m"


def c(text, color):
    return f"{color}{text}{RESET}"

def header(text):
    sep = "═" * 55
    print(f"\n{BOLD}{CYAN}{sep}{RESET}\n{BOLD}{CYAN}  {text}{RESET}\n{BOLD}{CYAN}{sep}{RESET}")

def ok(text):   print(f"  {GREEN}[ok]{RESET}  {text}")
def warn(text): print(f"  {YELLOW}[!]{RESET}   {text}")
def err(text):  print(f"  {RED}[x]{RESET}   {text}")
def info(text): print(f"  {CYAN}[i]{RESET}   {text}")
def dim(text):  print(f"  {DIM}{text}{RESET}")

def progress_bar(pct, width=25):
    filled = int(width * pct / 100)
    return f"{CYAN}{'█' * filled}{'░' * (width - filled)}{RESET}"

def ask(prompt, options=None):
    if options:
        for i, opt in enumerate(options, 1):
            print(f"    {BOLD}{i}.{RESET} {opt}")
        while True:
            raw = input(f"  {YELLOW}>{RESET} {prompt} [1-{len(options)}]: ").strip()
            if raw.isdigit() and 1 <= int(raw) <= len(options):
                return options[int(raw) - 1]
            warn("Opção inválida, tente novamente.")
    return input(f"  {YELLOW}>{RESET} {prompt}: ").strip()

def ask_yn(prompt, default=True):
    hint = "S/n" if default else "s/N"
    raw  = input(f"  {YELLOW}>{RESET} {prompt} [{hint}]: ").strip().lower()
    return default if raw == "" else raw in ("s", "sim", "y", "yes")

def log_failure(tag, name, url):
    with FAILED_LOG.open("a", encoding="utf-8") as f:
        f.write(f"{tag}\t{name}\t{url}\n")


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}

def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)
    ok(f"Configuração salva em {CONFIG_FILE}")

def setup_credentials():
    cfg = load_config()
    if cfg.get("api_id") and cfg.get("api_hash"):
        info(f"Credenciais salvas (api_id: {cfg['api_id']})")
        if ask_yn("Usar as credenciais salvas?"):
            return int(cfg["api_id"]), cfg["api_hash"]

    info("Acesse https://my.telegram.org → API Development para obter suas credenciais.")
    api_id_raw = ask("api_id (número inteiro)")
    api_hash   = ask("api_hash (string hex)")
    if not api_id_raw.isdigit():
        err("api_id deve ser um número inteiro."); sys.exit(1)
    if ask_yn("Salvar essas credenciais?"):
        cfg.update(api_id=api_id_raw, api_hash=api_hash)
        save_config(cfg)
    return int(api_id_raw), api_hash

def setup_account_type():
    header("Tipo de conta Telegram")
    info("Normal  → limite de upload: 2 GB (partes de 1800 MB)")
    info("Premium → limite de upload: 4 GB (partes de 3800 MB)")
    choice     = ask("Seu tipo de conta", ["Normal", "Premium"])
    split_size = SPLIT_NORMAL if choice == "Normal" else SPLIT_PREMIUM
    ok(f"Tamanho de corte: {split_size // MB} MB")
    return split_size


async def _resolve_entity(tg, chat_name):
    if chat_name == "Saved Messages":
        return await tg.get_me()
    async for dialog in tg.iter_dialogs():
        if dialog.name == chat_name:
            return dialog.entity
    return None

def _belongs_to_topic(msg, topic_id):
    rt     = getattr(msg, "reply_to", None)
    top_id = getattr(rt, "reply_to_top_id", None)
    mid_id = getattr(rt, "reply_to_msg_id", None)
    return top_id == topic_id or mid_id == topic_id or msg.id == topic_id

_PART_EXT_RE = re.compile(
    r"[_.](?:zip|7z|rar|iso|chd|cue|bin|img|rom|nes|sfc|gba|nds|3ds|ciso|rvz|wbfs)"
    r"[_.]part_?\d*$",
    re.IGNORECASE,
)
_PART_DOT_RE = re.compile(r"\.part_?\d*$", re.IGNORECASE)

def _strip_part_suffix(fname):
    def _restore_ext(m):
        raw = m.group(0)
        ext = re.search(
            r"zip|7z|rar|iso|chd|cue|bin|img|rom|nes|sfc|gba|nds|3ds|ciso|rvz|wbfs",
            raw, re.IGNORECASE,
        ).group(0)
        return "." + ext.lower()

    fname = _PART_EXT_RE.sub(_restore_ext, fname)
    fname = _PART_DOT_RE.sub("", fname)
    return fname

def _fname_from_msg(msg):
    if not msg.media or not isinstance(msg.media, MessageMediaDocument):
        return None
    for attr in getattr(msg.media.document, "attributes", []):
        fname = getattr(attr, "file_name", None)
        if fname:
            return _strip_part_suffix(fname)
    return None


async def pick_chat(tg):
    header("Selecionar destino")
    info("Lendo lista de chats...")

    dialogs = []
    async for d in tg.iter_dialogs():
        dialogs.append(d)
        if len(dialogs) >= 200:
            break

    print(f"\n  {BOLD}{'N°':<4} {'Nome'}{RESET}\n  {'─'*50}")
    print(f"  {YELLOW}{0:<4}{RESET} Mensagens Salvas")
    for i, d in enumerate(dialogs, 1):
        print(f"  {YELLOW}{i:<4}{RESET} {d.name}")

    raw = ask(f"\nEscolha o destino [0-{len(dialogs)}]")
    if not raw.isdigit() or not (0 <= int(raw) <= len(dialogs)):
        err("Opção inválida."); sys.exit(1)

    n = int(raw)
    if n == 0:
        ok("Destino: Mensagens Salvas")
        return "Saved Messages"

    chosen = dialogs[n - 1].name
    ok(f"Destino: {chosen}")
    return chosen

async def _fetch_topics_via_api(tg, entity):
    from telethon.tl.functions.messages import GetForumTopicsRequest
    from telethon.tl.types import ForumTopic

    try:
        peer = await tg.get_input_entity(entity)
    except Exception as e:
        warn(f"GetForumTopics: não obteve peer — {e}")
        return []

    topics = []
    offset_date = offset_id = offset_topic = 0

    while True:
        try:
            result = await tg(GetForumTopicsRequest(
                peer=peer, q=None,
                offset_date=offset_date, offset_id=offset_id,
                offset_topic=offset_topic, limit=100,
            ))
        except Exception as e:
            warn(f"GetForumTopics falhou: {e}")
            return []

        batch = getattr(result, "topics", [])
        for t in batch:
            if isinstance(t, ForumTopic):
                topics.append((t.id, t.title))

        if not batch or len(batch) < 100:
            break
        last         = batch[-1]
        offset_topic = getattr(last, "id", offset_topic)
        offset_date  = getattr(last, "date", offset_date)

    return topics

async def _fetch_topics_via_messages(tg, entity):
    warn("Usando fallback para detectar tópicos (últimas 200 msgs)...")
    seen_ids = set()

    async for msg in tg.iter_messages(entity, limit=200):
        rt = getattr(msg, "reply_to", None)
        if rt:
            top_id = getattr(rt, "reply_to_top_id", None) or getattr(rt, "reply_to_msg_id", None)
            if top_id:
                seen_ids.add(top_id)

    topics = []
    for tid in seen_ids:
        try:
            msgs = await tg.get_messages(entity, ids=tid)
            msg  = msgs if not isinstance(msgs, list) else (msgs[0] if msgs else None)
            if msg is None or getattr(msg, "empty", False):
                topics.append((tid, f"Tópico {tid}"))
                continue
            action = getattr(msg, "action", None)
            title  = getattr(action, "title", None)
            topics.append((tid, title if title else f"Tópico {tid}"))
        except Exception:
            topics.append((tid, f"Tópico {tid}"))
    return topics

async def pick_topic(tg, chat_name):
    entity = await _resolve_entity(tg, chat_name)
    if entity is None:
        return None

    try:
        topics = await _fetch_topics_via_api(tg, entity)
    except Exception as e:
        warn(f"Erro ao buscar tópicos: {e}")
        topics = []

    if not topics:
        topics = await _fetch_topics_via_messages(tg, entity)

    if not topics:
        return None
    if not ask_yn("Este chat tem tópicos. Escolher um?"):
        return None

    topics.sort()
    print(f"\n  {BOLD}{'N°':<4} {'Tópico':<40} {'Thread ID'}{RESET}\n  {'─'*55}")
    print(f"  {YELLOW}{0:<4}{RESET} [chat geral - sem tópico]")
    for i, (tid, nome) in enumerate(topics, 1):
        print(f"  {YELLOW}{i:<4}{RESET} {nome:<40} {DIM}{tid}{RESET}")

    raw = ask(f"\nEscolha o tópico [0-{len(topics)}]")
    if not raw.isdigit() or not (0 <= int(raw) <= len(topics)):
        err("Opção inválida."); sys.exit(1)

    n = int(raw)
    if n == 0:
        ok("Chat geral selecionado.")
        cfg = load_config(); cfg["last_topic_id"] = None; save_config(cfg)
        return None

    chosen_tid, chosen_name = topics[n - 1]
    if chosen_tid > 2_147_483_647:
        chosen_tid -= 4_294_967_296
    ok(f"Tópico: {chosen_name} (thread_id: {chosen_tid})")
    cfg = load_config(); cfg["last_topic_id"] = chosen_tid; save_config(cfg)
    return chosen_tid


def normalize_fname(name):
    stem = re.sub(r"\.part_\d+$", "", Path(name).stem)
    return re.sub(r"[^a-z0-9]", "", stem.lower())

def build_prefix_index(seen):
    index = {}
    for k in seen:
        index.setdefault(len(k), set()).add(k)
    return index

def fname_in_seen(myrient_key, index):
    mk_len = len(myrient_key)
    return any(
        myrient_key[:n] in keys
        for n, keys in index.items()
        if n <= mk_len
    )


async def fetch_last_uploaded(tg, chat_name, topic_id, files_ordered=None):
    info("Lendo última mensagem do tópico...")
    entity = await _resolve_entity(tg, chat_name)
    if entity is None:
        warn(f"Chat '{chat_name}' não encontrado, começando do zero.")
        return None

    key_to_idx = None
    if files_ordered:
        key_to_idx = {normalize_fname(n): i for i, (n, _) in enumerate(files_ordered)}

    async for msg in tg.iter_messages(entity, limit=None, reverse=False,
                                      reply_to=topic_id if topic_id else None):
        fname = _fname_from_msg(msg)
        if not fname:
            continue
        k = normalize_fname(fname)

        if key_to_idx is None:
            ok(f"Último arquivo no tópico: {fname}")
            return k

        pos = key_to_idx.get(k, -1)
        if pos == -1:
            for mk, mi in key_to_idx.items():
                if mk.startswith(k) and len(k) >= 10:
                    pos = mi
                    break
        if pos == -1:
            continue
        ok(f"Último arquivo no tópico: {files_ordered[pos][0]}")
        return normalize_fname(files_ordered[pos][0])

    info("Nenhum arquivo encontrado no tópico, começando do zero.")
    return None

async def fetch_all_uploaded(tg, chat_name, topic_id):
    info("Lendo histórico completo (pode demorar para chats grandes)...")
    entity = await _resolve_entity(tg, chat_name)
    if entity is None:
        warn(f"Chat '{chat_name}' não encontrado, começando do zero.")
        return set()

    seen = set()
    async for msg in tg.iter_messages(entity, limit=None, wait_time=0, reverse=False,
                                      reply_to=topic_id if topic_id else None):
        fname = _fname_from_msg(msg)
        if fname:
            seen.add(normalize_fname(fname))
            if len(seen) % 100 == 0:
                print(f"\r  {DIM}...{len(seen)} arquivos lidos{RESET}   ", end="", flush=True)

    print()
    ok(f"{len(seen)} arquivo(s) encontrados no histórico.")

    sample = sorted(seen)
    info("Amostra (ordem alfabética):")
    for s in sample[:3]:  dim(f"  '{s}'")
    dim("  ...")
    for s in sample[-3:]: dim(f"  '{s}'")
    return seen


async def upload_to_telegram(tg, path, caption, chat_name, topic_id, retries=3):
    size_mb = path.stat().st_size / MB
    info(f"Enviando {path.name} ({size_mb:.1f} MB)...")

    entity = await _resolve_entity(tg, chat_name)
    if entity is None:
        raise RuntimeError(f"Chat '{chat_name}' não encontrado.")

    last_pct = [-1.0]
    start_t  = [time.time()]

    def progress_callback(done, total):
        pct = min(done / total * 100, 100) if total else 0
        if abs(pct - last_pct[0]) < 0.5 and pct < 100:
            return
        last_pct[0] = pct
        elapsed = time.time() - start_t[0]
        speed   = done / elapsed / MB if elapsed > 0 else 0
        print(
            f"\r  {progress_bar(pct)} {pct:5.1f}%  {done/MB:.1f}/{total/MB:.1f} MB  {speed:.1f} MB/s   ",
            end="", flush=True,
        )

    for attempt in range(1, retries + 1):
        try:
            start_t[0] = time.time()
            with open(path, "rb") as f:
                uploaded = await _ft_upload_file(tg, f, progress_callback=progress_callback)
            print()

            send_kwargs = dict(
                entity=entity,
                file=uploaded,
                caption=caption,
                force_document=True,
                attributes=[DocumentAttributeFilename(file_name=path.name)],
            )
            if topic_id is not None:
                send_kwargs["reply_to"] = topic_id

            await tg.send_file(**send_kwargs)
            ok(f"Upload concluído: {path.name}")
            return

        except Exception as e:
            print()
            err(f"Tentativa {attempt}/{retries} falhou: {e}")
            if attempt < retries:
                await asyncio.sleep(5)

    raise RuntimeError(f"Falha permanente no upload de {path.name}")


def parse_directory(url):
    resp = httpx.get(url, timeout=30, follow_redirects=True)
    resp.raise_for_status()
    soup  = BeautifulSoup(resp.text, "html.parser")
    table = soup.find("table")
    if not table:
        return [], []

    skip    = {"../", "/", "./", "..", ".", "Parent directory/"}
    folders, files = [], []
    for a in table.find_all("a", href=True):
        href, name = a["href"], a.get_text(strip=True)
        if href.startswith("?") or name in skip or href in skip:
            continue
        full = href if href.startswith("http") else f"{url.rstrip('/')}/{href.lstrip('/')}"
        if href.endswith("/"):
            folders.append((name.rstrip("/"), full))
        else:
            files.append((name, full))

    return folders, files

async def pick_files(files):
    print(f"\n  {BOLD}{'N°':<4} {'Arquivo'}{RESET}\n  {'─'*50}")
    for i, (name, _) in enumerate(files, 1):
        print(f"  {YELLOW}{i:<4}{RESET} {name}")

    info("Digite os números separados por vírgula (ex: 1,3,5) ou 'todos'.")
    raw = ask("Arquivos para baixar").strip().lower()
    if raw == "todos":
        return files

    selected = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit() and 1 <= int(part) <= len(files):
            selected.append(files[int(part) - 1])
        else:
            warn(f"Número inválido ignorado: {part}")

    if not selected:
        warn("Nenhum arquivo válido selecionado.")
    else:
        ok(f"{len(selected)} arquivo(s) selecionado(s).")
    return selected


_SKIP_TAGS = re.compile(
    r"\((Demo|Sample|Proto|Beta|Prototype|Aftermarket|Pirate|Unl|Hack|"
    r"Homebrew|Test Program|BIOS|Program|Enhancement Chip|Competition|"
    r"Promo|Reprint|Bonus Disc|Disc [2-9])\)",
    re.IGNORECASE,
)
_REGION_PRIORITY = [
    r"\(Pt\)", r"\(Portugal\)", r"\(Brazil\)", r"\(Brasil\)",
    r"\(Europe\)", r"\(USA, Europe\)", r"\(Europe, USA\)",
    r"\(USA\)", r"\(World\)",
]
_DISC_TAG = re.compile(r"\(Disc\s*(\d+)\)", re.IGNORECASE)
_REV_TAG  = re.compile(r"\(Rev\s*([0-9A-Z]+)\)", re.IGNORECASE)
_VER_TAG  = re.compile(r"\(v(\d+(?:\.\d+)*)\)", re.IGNORECASE)
_ROM_EXTS = {
    ".zip", ".7z", ".rar", ".iso", ".chd", ".cue",
    ".bin", ".img", ".rom", ".nes", ".sfc", ".gba",
    ".nds", ".3ds", ".ciso", ".rvz", ".wbfs",
}

def _rom_base_name(f):
    n = re.sub(r"\(.*?\)", "", Path(f).stem)
    return re.sub(r"\[.*?\]", "", n).strip().lower()

def _disc_number(f):
    m = _DISC_TAG.search(f)
    return int(m.group(1)) if m else 1

def _rev_score(f):
    m = _REV_TAG.search(f)
    if m:
        try:    return tuple(int(x) for x in m.group(1).split("."))
        except: return (ord(m.group(1)[0]),) if m.group(1) else (0,)
    m = _VER_TAG.search(f)
    if m:
        try:    return tuple(int(x) for x in m.group(1).split("."))
        except: return (0,)
    return (0,)

def _region_score(f):
    for i, p in enumerate(_REGION_PRIORITY):
        if re.search(p, f, re.IGNORECASE):
            return i
    return len(_REGION_PRIORITY)

def _is_multi_disc(f):
    return bool(_DISC_TAG.search(f))

def filter_roms(files):
    skipped = []
    no_skip = []
    for name, url in files:
        if _SKIP_TAGS.search(name) and not _is_multi_disc(name):
            skipped.append(name)
        else:
            no_skip.append((name, url))

    groups  = {}
    non_rom = []
    for name, url in no_skip:
        if Path(name).suffix.lower() not in _ROM_EXTS:
            non_rom.append((name, url))
        else:
            groups.setdefault(_rom_base_name(name), []).append((name, url))

    kept = []
    for variants in groups.values():
        multi  = [(n, u) for n, u in variants if _is_multi_disc(n)]
        single = [(n, u) for n, u in variants if not _is_multi_disc(n)]

        if multi:
            disc_groups = {}
            for n, u in multi:
                disc_groups.setdefault((_region_score(n), _rev_score(n)), []).append((n, u))
            best_key = min(disc_groups, key=lambda k: (k[0], [-x for x in k[1]]))
            kept.extend(sorted(disc_groups[best_key], key=lambda x: _disc_number(x[0])))
            for k, ds in disc_groups.items():
                if k != best_key:
                    skipped.extend(d[0] for d in ds)
            skipped.extend(n for n, _ in single)
        else:
            best_region = min(_region_score(n) for n, _ in single)
            candidates  = [(n, u) for n, u in single if _region_score(n) == best_region]
            best        = max(candidates, key=lambda x: _rev_score(x[0]))
            kept.append(best)
            skipped.extend(n for n, u in single if (n, u) != best)

    if skipped:
        warn(f"{len(skipped)} arquivo(s) ignorado(s) (demos, duplicatas, regiões inferiores):")
        for s in skipped[:10]: dim(f"  - {s}")
        if len(skipped) > 10:  dim(f"  ... e mais {len(skipped) - 10}")

    result = non_rom + kept
    ok(f"{len(result)} arquivo(s) selecionado(s) após filtro.")
    return result


def _aria2c_cmd():
    return str(ARIA2C_WIN) if platform.system() == "Windows" and ARIA2C_WIN.exists() else "aria2c"

def _aria2c_available():
    try:
        subprocess.run([_aria2c_cmd(), "--version"], capture_output=True, check=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False

def _download_aria2c_windows():
    import urllib.request
    info("Procurando versão mais recente do aria2c...")
    try:
        req = urllib.request.Request(
            "https://api.github.com/repos/aria2/aria2/releases/latest",
            headers={"User-Agent": "Mozilla/5.0"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())

        assets = data.get("assets", [])
        asset  = next(
            (a for a in assets if "win-64" in a["name"] and a["name"].endswith(".zip")),
            next((a for a in assets if "win" in a["name"].lower() and a["name"].endswith(".zip")), None),
        )
        if not asset:
            err("Não encontrei download do aria2c para Windows."); return False

        info(f"Baixando aria2c {data.get('tag_name', '?')}...")
        ARIA2C_DIR.mkdir(parents=True, exist_ok=True)
        zip_path = ARIA2C_DIR / asset["name"]
        dl = [0]

        def hook(b, bs, t):
            dl[0] += bs
            pct = min(dl[0] / t * 100, 100) if t else 0
            print(f"\r  {progress_bar(pct)} {pct:5.1f}%", end="", flush=True)

        urllib.request.urlretrieve(asset["browser_download_url"], zip_path, hook)
        print()

        with zipfile.ZipFile(zip_path) as zf:
            for m in zf.namelist():
                if m.lower().endswith("aria2c.exe"):
                    ARIA2C_WIN.write_bytes(zf.read(m)); break
        zip_path.unlink(missing_ok=True)

        if ARIA2C_WIN.exists():
            ok(f"aria2c instalado em: {ARIA2C_WIN}"); return True
        err("aria2c.exe não encontrado no zip."); return False

    except Exception as e:
        err(f"Falha ao baixar aria2c: {e}"); return False

def ensure_aria2c():
    if _aria2c_available():
        return True
    err("aria2c não encontrado.")
    system = platform.system()
    if system == "Windows":
        return ask_yn("Baixar e instalar aria2c automaticamente?") and _download_aria2c_windows()
    instructions = {
        "Darwin": ["brew install aria2"],
        "Linux":  ["sudo apt install aria2", "sudo pacman -S aria2", "sudo dnf install aria2"],
    }
    for cmd in instructions.get(system, []):
        info(f"Instale com: {cmd}")
    return False

def download_file(url, dest, retries=10):
    for attempt in range(1, retries + 1):
        try:
            proc = subprocess.Popen([
                _aria2c_cmd(),
                "-x", "16", "-s", "16", "-k", "1M",
                "--continue=true",
                "--auto-file-renaming=false",
                "--file-allocation=none",
                "--console-log-level=error",
                "--summary-interval=1",
                "--show-console-readout=true",
                "--disable-ipv6=true",
                f"--header=Referer: https://myrient.erista.me/",
                "--retry-wait=5",
                "--max-tries=3",
                "-d", str(dest.parent),
                "-o", dest.name,
                url,
            ])
            proc.wait()
            if proc.returncode == 0:
                ok(f"Download concluído: {dest.name}"); return True
            err(f"aria2c falhou (código {proc.returncode}) — tentativa {attempt}/{retries}")
            dest.unlink(missing_ok=True)
            if attempt < retries:
                wait = min(attempt * 5, 60)
                warn(f"Aguardando {wait}s..."); time.sleep(wait)
        except KeyboardInterrupt:
            proc.terminate(); proc.wait()
            err("Download interrompido.")
            dest.unlink(missing_ok=True); return False
        except FileNotFoundError:
            err("aria2c não encontrado!"); sys.exit(1)

    log_failure("DOWNLOAD_FAIL", dest.name, url)
    err(f"Falha permanente: {dest.name} — registrado em {FAILED_LOG}")
    return False


def split_if_needed(path, split_size):
    if not path.exists():
        err(f"Arquivo não encontrado: {path}"); return []

    file_size = path.stat().st_size
    if file_size <= split_size:
        return [path]

    total_parts = -(-file_size // split_size)
    info(f"Dividindo {path.name} em {total_parts} partes de {split_size // MB} MB...")
    parts = []

    with open(path, "rb") as src:
        part_num = 1
        while True:
            part_path     = path.parent / f"{path.name}.part_{part_num:04d}"
            bytes_written = 0
            eof           = False
            with open(part_path, "wb") as dst:
                while bytes_written < split_size:
                    chunk = src.read(min(READ_CHUNK, split_size - bytes_written))
                    if not chunk:
                        eof = True; break
                    dst.write(chunk)
                    bytes_written += len(chunk)

            if bytes_written == 0:
                part_path.unlink(missing_ok=True); break

            parts.append(part_path)
            pct = part_num / total_parts * 100
            print(
                f"\r  {progress_bar(pct)}  Parte {part_num}/{total_parts}  ({pct:.0f}%)",
                end="", flush=True,
            )
            part_num += 1
            if eof:
                break

    print()
    path.unlink()
    ok(f"{len(parts)} partes geradas.")
    return parts


async def _resolve_file_list(tg, files, chat_name, topic_id):
    print()
    print(f"  {DIM}[1] Continuar — retoma a partir do último arquivo no chat{RESET}")
    print(f"  {DIM}[2] Lacunas   — cruza histórico completo, baixa só o que falta{RESET}")
    modo = ask("Modo [1/2]") or "1"

    if modo == "1":
        last_key = await fetch_last_uploaded(tg, chat_name, topic_id, files_ordered=files)
        all_seen = None
    else:
        last_key = await fetch_last_uploaded(tg, chat_name, topic_id)
        all_seen = await fetch_all_uploaded(tg, chat_name, topic_id)

    if modo == "2":
        if last_key:
            cfg = load_config()
            cfg["gap_resume_key"] = last_key
            save_config(cfg)
            info(f"Marco de retomada salvo: '{last_key}'")

        cutoff_idx = next(
            (i for i, (n, _) in enumerate(files) if normalize_fname(n) == last_key),
            None,
        )
        files_before = files[:cutoff_idx] if cutoff_idx is not None else files
        if cutoff_idx is not None:
            info(f"Verificando lacunas nos {cutoff_idx} arquivo(s) antes de '{files[cutoff_idx][0]}'")
        elif last_key:
            warn("Último arquivo não encontrado — verificando toda a lista")

        prefix_index = build_prefix_index(all_seen)
        exact  = sum(1 for n, _ in files_before if normalize_fname(n) in all_seen)
        prefix = sum(1 for n, _ in files_before
                     if normalize_fname(n) not in all_seen
                     and fname_in_seen(normalize_fname(n), prefix_index))
        info(f"  Diagnóstico: {exact} match exato, {prefix} match só por prefixo")

        result = [(n, u) for n, u in files_before if not fname_in_seen(normalize_fname(n), prefix_index)]
        skipped = len(files_before) - len(result)
        if skipped:
            warn(f"{skipped} arquivo(s) já no chat, pulando.")
        if not result:
            ok("Nenhuma lacuna encontrada!")
        else:
            info(f"{len(result)} lacuna(s) encontrada(s).")
            for name, _ in result[:3]:
                info(f"  LACUNA: '{name}'")
        return result

    else:
        cfg = load_config()
        gap_resume = cfg.get("gap_resume_key")
        if gap_resume:
            ok(f"Marco de retomada encontrado: '{gap_resume}'")
            resp = ask("Usar este marco em vez do último arquivo do chat? [S/n]") or "s"
            if resp.lower() != "n":
                last_key = gap_resume
                cfg.pop("gap_resume_key", None)
                save_config(cfg)
                info("Marco de retomada usado e removido do config.")

        if last_key:
            cutoff_idx = next(
                (i for i, (n, _) in enumerate(files) if normalize_fname(n) == last_key),
                None,
            )
            if cutoff_idx is not None:
                warn(f"Retomando após '{files[cutoff_idx][0]}' ({cutoff_idx+1}/{len(files)}).")
                return files[cutoff_idx + 1:]
            warn("Último arquivo não encontrado — começando do início.")
        return files

async def download_folder(tg, files, folder_name, split_size, chat_name, topic_id, apply_filter=False):
    if apply_filter:
        info("Aplicando filtro de ROMs...")
        files = filter_roms(files)
        if not files:
            warn("Nenhum arquivo restou após o filtro."); return

    files = await _resolve_file_list(tg, files, chat_name, topic_id)
    if not files:
        ok("Todos os arquivos já foram enviados."); return

    info("Amostra dos arquivos a processar (primeiros 3):")
    for name, _ in files[:3]: dim(f"  '{name}'")

    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    total = len(files)

    for idx, (name, url) in enumerate(files, 1):
        print(f"\n  {BOLD}[{idx}/{total}]{RESET} {c(name, CYAN)}")
        dest_path = DOWNLOAD_DIR / name

        if not await asyncio.to_thread(download_file, url, dest_path):
            err(f"Falha no download de {name}, pulando.")
            log_failure("DOWNLOAD_FAIL", name, url)
            dest_path.unlink(missing_ok=True)
            continue

        upload_ok = True
        try:
            info("Verificando arquivo...")
            parts       = await asyncio.to_thread(split_if_needed, dest_path, split_size)
            total_parts = len(parts)
            for part_idx, part_path in enumerate(parts, 1):
                caption = f"{folder_name}/{name}"
                if total_parts > 1:
                    caption += f"  [{part_idx}/{total_parts}]"
                try:
                    await upload_to_telegram(tg, part_path, caption, chat_name, topic_id)
                except Exception as e:
                    err(f"Falha no upload de {name} (parte {part_idx}): {e}")
                    log_failure("UPLOAD_FAIL", name, url)
                    upload_ok = False
                    break
                finally:
                    part_path.unlink(missing_ok=True)
                    dim(f"Parte {part_idx}/{total_parts} removida do disco.")
        finally:
            dest_path.unlink(missing_ok=True)

        if upload_ok:
            ok(f"{name} concluído e removido do disco.")
        else:
            warn(f"{name} removido do disco (falha no upload — ver {FAILED_LOG}).")


async def browse(tg, split_size, chat_name, topic_id, current_url=BASE_URL, breadcrumb="/"):
    while True:
        info(f"\nLocal atual: {c(breadcrumb, CYAN)}")
        try:
            folders, files = parse_directory(current_url)
        except Exception as e:
            err(f"Erro ao acessar {current_url}: {e}"); return

        if not folders and not files:
            warn("Diretório vazio."); return

        items = []
        if breadcrumb != "/":
            items.append(("<  Voltar", "__back__"))
        for name, url in folders:
            items.append((f"[pasta]  {name}/", url))
        if files:
            n = len(files)
            items.append((f"[baixar]  ESTA PASTA inteira  [{n} arquivo(s)]", "__download__"))
            items.append((f"[arquivos]  Ver arquivos individualmente  [{n} arquivo(s)]", "__list_files__"))
        items.append(("[raiz]  Voltar para a raiz", "__root__"))
        items.append(("[sair]  Sair", "__quit__"))

        print(f"\n  {BOLD}{'N°':<4} {'Item'}{RESET}\n  {'─'*50}")
        for i, (label, _) in enumerate(items, 1):
            print(f"  {YELLOW}{i:<4}{RESET} {label}")

        raw = ask(f"\nEscolha [1-{len(items)}]")
        if not raw.isdigit() or not (1 <= int(raw) <= len(items)):
            warn("Opção inválida."); continue

        label, target = items[int(raw) - 1]

        if target == "__quit__":
            ok("Até mais!"); sys.exit(0)
        elif target == "__root__":
            await browse(tg, split_size, chat_name, topic_id, BASE_URL, "/"); return
        elif target == "__back__":
            return
        elif target == "__list_files__":
            selected = await pick_files(files)
            if selected:
                await download_folder(tg, selected, breadcrumb, split_size, chat_name, topic_id)
                ok(f"Arquivos selecionados de {c(breadcrumb, GREEN)} concluídos!")
        elif target == "__download__":
            if not files:
                warn("Nenhum arquivo nesta pasta.")
            else:
                apply_filter = ask_yn("Filtrar ROMs? (ignora demos, duplicatas, prioriza PT/Europe/USA)")
                await download_folder(tg, files, breadcrumb, split_size, chat_name, topic_id, apply_filter=apply_filter)
                ok(f"Pasta {c(breadcrumb, GREEN)} concluída!")
                await browse(tg, split_size, chat_name, topic_id, BASE_URL, "/"); return
        else:
            folder_label = label.replace("[pasta]  ", "").rstrip("/")
            new_bc       = f"{breadcrumb.rstrip('/')}/{folder_label}"
            await browse(tg, split_size, chat_name, topic_id, target, new_bc)


async def main():
    header("Myrient → Telegram Backup")
    print(f"  {DIM}Python {sys.version.split()[0]} | Telethon + FastTelethon (MTProto direto){RESET}\n")

    for _lg in ("telethon", "telethon.network", "telethon.crypto", "asyncio"):
        logging.getLogger(_lg).setLevel(logging.CRITICAL)

    if not ensure_aria2c():
        sys.exit(1)

    api_id, api_hash = setup_credentials()
    split_size       = setup_account_type()

    async with TelegramClient("myrient_session", api_id, api_hash) as tg:
        info("Conectado ao Telegram via MTProto.")
        chat_name = await pick_chat(tg)
        topic_id  = await pick_topic(tg, chat_name)
        info("\nIniciando navegação no Myrient...")
        await browse(tg, split_size, chat_name, topic_id)

if __name__ == "__main__":
    asyncio.run(main())
