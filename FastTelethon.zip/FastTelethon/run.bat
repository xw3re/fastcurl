@echo off
title Myrient - Telegram Backup
if not exist venv\Scripts\activate.bat (
    echo  [ERRO] Ambiente virtual nao encontrado.
    echo  Execute install.bat primeiro.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python myrient.py
pause
